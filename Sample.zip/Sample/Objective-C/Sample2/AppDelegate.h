//
//  AppDelegate.h
//  Sample2
//
//  Created by Zaid M. Said on 31/08/2018.
//  Copyright © 2018 Kiple Sdn Bhd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <KPPaymentSDK/KPPaymentSDK-Swift.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

