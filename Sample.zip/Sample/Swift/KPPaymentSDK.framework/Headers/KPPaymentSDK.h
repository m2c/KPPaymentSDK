//
//  Copyright © 2018 Kiple Sdn Bhd. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for KPPaymentSDK.
FOUNDATION_EXPORT double KPPaymentSDKVersionNumber;

//! Project version string for KPPaymentSDK.
FOUNDATION_EXPORT const unsigned char KPPaymentSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <KPPaymentSDK/PublicHeader.h>


